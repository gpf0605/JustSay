//
//  AppDelegate.swift
//  Just Say
//
//  Created by admin on 16/3/8.
//  Copyright © 2016年 gpf. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate ,RCIMUserInfoDataSource {

    var window: UIWindow?
    
    //
    //储存用户头像信息
    /**
    储存用户头像：
    1、遵循协议：RCIMUserInfoDataSource
    2、实现协议接口：getUserInfoWithUserId
    3、设置代理：代理为self
    - parameter userId:     <#userId description#>
    - parameter completion: <#completion description#>
    */
    func getUserInfoWithUserId(userId: String!, completion: ((RCUserInfo!) -> Void)!) {
        
        let userInfo = RCUserInfo()
        userInfo.userId = userId
        
        switch userId {
        
            case "levis":
                userInfo.name = "谷鹏飞"
                userInfo.portraitUri = "http://img4.duitang.com/uploads/item/201602/23/20160223040031_Eus8e.thumb.700_0.jpeg"
            case "levis2":
                userInfo.name = "谷鹏飞2"
                userInfo.portraitUri = "http://image14-c.poco.cn/mypoco/qing/20130308/21/1163854899971726336_400x300_210.gif"
            case "wujiaru":
                userInfo.name = "吴家儒"
                userInfo.portraitUri = "http://img2.3lian.com/2014/f5/158/d/86.jpg"
            default:
                print("不存在该用户")
        
        }
        
        return completion(userInfo)
        
        
    }
    
    //链接融云服务器
    func connectSever(completion:()->Void){
        
        //从自己的服务器获取token
        let token = "ZHYkofj9n1FWBmcGyTuo8ByH4btao0KZjtwFjKCMl15Ocg0BCs+z7O9hTXwt10gSyhXHgj4Qhn7N9ntMVStMNQ=="
        
        
        //通过自己的服务器获取的token开始链接融云的服务器
        RCIM.sharedRCIM().connectWithToken(token, success: { (userId) -> Void in
            
            print("链接成功，当前的用户ID:\(userId)")
            //当链接成功的时候的时候，获取主线程，做一些刷新回话列表
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                
                completion()
                
            })
            
            }, error: { (status) -> Void in
                
                print("登陆错误码是\(status)")
                
            }) { () -> Void in
                
                print("链接的token有错误")
                
        }
    
        
    
    
    }
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        //设置Appkey是为了为了链接融云的服务器的一把钥匙
        RCIM.sharedRCIM().initWithAppKey("tdrvipksrbkx5")
        RCIM.sharedRCIM().userInfoDataSource = self
        
        
        return true
    }

    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

